package com.project.fooisLife.service.register;

import com.project.fooisLife.entity.Branch;
import com.project.fooisLife.entity.Admin;

public interface StoreRegisterService {
	
	public int registerStoreService(Branch branch, Admin admin);
}
