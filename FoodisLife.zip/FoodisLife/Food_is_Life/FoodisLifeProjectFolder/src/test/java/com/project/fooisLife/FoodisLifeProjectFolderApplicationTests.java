package com.project.fooisLife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodisLifeProjectFolderApplicationTests {

	@Test
	void contextLoads() {
	}

}
