import React, { useEffect, useState } from "react";
import Container from "@material-ui/core/Container";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import CartCard from "components/Cards/CartCard";
axios.defaults.withCredentials = true;
axios.defaults.headers.get["Access-Control-Allow-Origin"] = "*";
function Cart() {
  const getAllFoodItems = () => {
    axios.get("http://localhost:8086/NGO/Cart/fetchCartItems").then(
      (response) => {
        console.log(response.data);
        setFoodItems(response.data);
      },
      (error) => {
        console.log(error);
      }
    );
  };
  useEffect(() => {
    getAllFoodItems();
  }, []);

  const [foodItems, setFoodItems] = useState([]);

  return (
    <Container className=" m-0 text-right">
      <ToastContainer />
      <div className=" pt-20 mt-10">
        <h1 className="font-bold text-4xl text-center ">CART ITEMS</h1>
        {foodItems.length > 0
          ? foodItems.map((item) => <CartCard items={item} />)
          : "NO ITEM IN THE CART"}
        <button
          className=" bg-blueGray-800 text-white active:bg-blueGray-600 text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150"
          type="submit"
        >
          Order
        </button>
      </div>
    </Container>
  );
}

export default Cart;
