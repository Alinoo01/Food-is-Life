import React from "react";

export default function RemoveRiderDetails() {
  return <div>RemoveRiderDetails</div>;
}
