import React from "react";

export default function UpdateRiderDetails() {
  return <div>UpdateRiderDetails</div>;
}
