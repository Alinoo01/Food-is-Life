export default function UpdateLeftovers() {
  return (
    <div>
      <h1>Update LeftOvers</h1>
    </div>
  );
}
