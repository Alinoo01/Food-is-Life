import React from "react";
export default function RemoveFoodItems() {
  return (
    <div>
      <h1>Remove Food Items</h1>
    </div>
  );
}
